import login from '@/client/js/auth/login';

export default async function authCheck(gameName, roomName, pid) {
  const auth = await fetch(`/api/user-info`, {
    method: 'GET',
    credentials: 'include', // 쿠키(authToken)를 함께 보냄
  });

  if (auth.ok) {
    const authData = await auth.json();
    if (authData.status === 'unauthorized') {
      console.log('처음 진입 : ', authData.message);
      await login(gameName, roomName, pid);
    } else {
      console.log('새로고침 인증 성공 : ', authData);
    }
  } else {
    // 브라우저 cookie의 authToken을 조작하면 이부분을 탐
    throw { errCase: 'auth', component: 'token', event: 'unauthorized', message: 'Token verification failed' };
  };
};
