import webRTC from '@/client/js/webRTC/rtcConn';
import initNickName from '@/client/js/functions/initNickName';
import waitPeer from '@/client/js/functions/waitPeer';
import findNickname from '@/client/js/functions/findNickname';

export default async function rtcPeer(gameName) {
  return new Promise(async (resolve, reject) => {
    try {
      /**
       * 게임화면에 직접 진입 했는데,
       * localStorage에 localPlayer 가 없을 경우,
       * localPlayer를 만들 때 까지 대기 후 webRTC 연결
       */
      await initNickName();

      waitPeer(1, findNickname('localPlayer'));

      await webRTC(gameName);

      waitPeer(2);

      resolve();
    } catch (error) {
      console.log('error webPeer.js >>>>>>>>>>>> ', error);

      reject(error);
    }
  });
}
