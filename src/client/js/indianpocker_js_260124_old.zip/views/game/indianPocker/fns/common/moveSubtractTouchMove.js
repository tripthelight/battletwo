import { errorManagement } from '@/client/js/module/errorHandler/errorManagement';
import { reactiveState } from '@/client/js/views/game/indianPocker/fns/common/variable';
import touchCoinState from '@/client/js/views/game/indianPocker/fns/common/touchCoinState';

export default (e) => {
  if (!touchCoinState(e.target)) return;
  reactiveState.mmX = -(reactiveState.selectX - e.targetTouches[0].clientX) + reactiveState.mtX;
  reactiveState.mmY = -(reactiveState.selectY - e.targetTouches[0].clientY) + reactiveState.mtY;
  e.target.style.zIndex = '3000';
  e.target.style.transform = 'translate(' + reactiveState.mmX + 'px, ' + reactiveState.mmY + 'px)';
  const BETTING_ZONE = document.querySelector('.betting-zone');
  if (!BETTING_ZONE) return errorManagement({ errCase: 'errorComn', message: '.betting-zone 엘리먼트를 찾을 수 없습니다.' });
  const PLAYER_BLOCK = document.querySelector('.player-block');
  if (!PLAYER_BLOCK) return errorManagement({ errCase: 'errorComn', message: '.player-block 엘리먼트를 찾을 수 없습니다.' });
  if (reactiveState.mmY > BETTING_ZONE.clientHeight) {
    // player 코인 영역
    PLAYER_BLOCK.classList.add('over');
  } else {
    // batting zone 코인 영역
    PLAYER_BLOCK.classList.remove('over');
  }
};
