import { errorManagement } from '@/client/js/module/errorHandler/errorManagement';
import BattingZoneMoveRt from '@/client/js/views/game/indianPocker/fns/common/BattingZoneMoveRt';
import posClock from '@/client/js/views/game/indianPocker/fns/common/posClock';
import roundEndBetEnemyMoveXY from '@/client/js/views/game/indianPocker/fns/common/roundEndBetEnemyMoveXY';
import roundEndBetMoveEnd from '@/client/js/views/game/indianPocker/fns/common/roundEndBetMoveEnd';

export default (_state) => {
  return new Promise((resolve, reject) => {
    // let STATE_CASE = ['win', 'lose'];
    const STATE_CASE = [0, 1];
    if (STATE_CASE.filter((item) => _state === item).length) {
      const BET_COINS = document.querySelector('.bet-coins');
      if (!BET_COINS) return errorManagement({ errCase: 'elementLoss', message: '.betting-zone에서 .enemy-block으로 칩을 옯길 때 .bet-coins 엘리먼트가 없습니다' });
      const BET_COIN_RES_ARR = BattingZoneMoveRt();
      let cw = 0;
      let ch = 0;
      let ty = 0;
      let enemyX = 0;
      let enemyY = 0;
      let aniTime = Number(3000 / (BET_COIN_RES_ARR.length + 1));
      for (let i = 0, p = Promise.resolve(); i < BET_COIN_RES_ARR.length; i++) {
        p = p
          .then(function () {
            return roundEndBetMoveEnd(Number(aniTime));
          })
          .then(function () {
            const BET_COIN_EL = document.querySelector('.bet-coins');
            if (!BET_COIN_EL) return errorManagement({ errCase: 'elementLoss', message: 'round end에서 .bet-coins 엘리먼트가 없습니다' });
            const BET_COINS_EL = BET_COIN_EL.querySelectorAll('li');
            if (!BET_COINS_EL) return errorManagement({ errCase: 'elementLoss', message: 'round end에서 .bet-coins li 엘리먼트가 없습니다' });

            const BET_COINS_ELEM = BET_COINS_EL[0];
            cw = BET_COINS_ELEM.clientWidth;
            ty = BET_COIN_RES_ARR[i].translateY;
            ch = BET_COINS_ELEM.clientHeight;

            // call case
            // if (_state === 'lose') {
            if (_state === 0) {
              enemyX = roundEndBetEnemyMoveXY(cw, ch, ty, 'end').x;
              enemyY = roundEndBetEnemyMoveXY(cw, ch, ty, 'end').y;
            // } else if (_state === 'win') {
            } else if (_state === 1) {
              enemyX = roundEndBetEnemyMoveXY(cw, ch, ty, 'add').x;
              enemyY = roundEndBetEnemyMoveXY(cw, ch, ty, 'add').y;
            }
            BET_COINS_ELEM.style.transition = 'transform ' + Number(aniTime / 1000) + 's ease-in';
            BET_COINS_ELEM.style.transform = 'translate(' + enemyX + 'px, ' + enemyY + 'px)';

            // call case
            return {
              el: BET_COINS_ELEM,
              // state: _state === 'lose' ? document.querySelector('.coins-enemy') : _state === 'win' ? document.querySelector('.coins-player') : undefined,
              state: _state === 0 ? document.querySelector('.coins-enemy') : _state === 1 ? document.querySelector('.coins-player') : undefined,
              result: _state,
            };
          })
          .then(function (_data) {
            setTimeout(() => {
              if (_data.state) {
                let liEl = document.createElement('li');
                let minuteEl = document.createElement('span');
                let hourEl = document.createElement('span');
                minuteEl.classList.add('m');
                hourEl.classList.add('h');
                liEl.appendChild(minuteEl);
                liEl.appendChild(hourEl);
                posClock(hourEl, minuteEl);
                _data.state.appendChild(liEl);
              }
              _data.el.remove();
              if (i === BET_COIN_RES_ARR.length - 1) resolve(_data.result);
            }, Number(aniTime));
          });
      }
    } else {
      return errorManagement({ errCase: 'errorComn', message: 'call 이후 win | lose 가 아닙니다 :: ' });
    }
  });
};
