import { timeInterval_1 } from '@/client/js/functions/variable';
import { reactiveState } from '@/client/js/views/game/indianPocker/fns/common/variable';
import betCoinEndComn from '@/client/js/views/game/indianPocker/fns/common/betCoinEndComn';

export default (e) => {
  const BETTING_ZONE = document.querySelector('.betting-zone');
  if (!BETTING_ZONE) return;
  reactiveState.selectX = 0;
  reactiveState.selectY = 0;
  e.target.style.zIndex = '1';
  if (BETTING_ZONE.classList.contains('over')) {
    BETTING_ZONE.classList.remove('over');
    setTimeout(betCoinEndComn, timeInterval_1, e);
  } else {
    e.target.style.transform = 'translate(' + reactiveState.selectX + 'px, ' + reactiveState.selectY + 'px)';
  }
};
