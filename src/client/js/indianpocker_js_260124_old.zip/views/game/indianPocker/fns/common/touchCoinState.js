import { reactiveState } from '@/client/js/views/game/indianPocker/fns/common/variable';

export default (dragCoin) => {
  const BET_COINS = Array.from(dragCoin.closest('ul').children);
  if (!BET_COINS) return false;
  reactiveState.mTargetIdx = BET_COINS.indexOf(dragCoin);
  const COIN_BET = window.sessionStorage.betCoin;
  if (!COIN_BET) return false;
  const COIN_BET_ARR = JSON.parse(COIN_BET);
  if (!COIN_BET_ARR || COIN_BET_ARR.length <= 0) return false;
  if (COIN_BET_ARR[reactiveState.mTargetIdx].host === 'enemy') return false;
  if (COIN_BET_ARR[reactiveState.mTargetIdx].betState === 'end') return false;
  return true;
};
