import findCharCode from '@/client/js/functions/findCharCode';
import { enc, dec } from '@/client/js/module/crypts/obf8lower';
import storageMethod from '@/client/js/module/storage/storageMethod';
import { timeInterval_1 } from '@/client/js/functions/variable';
import { comnText } from '@/client/js/functions/language';
import { errorManagement } from '@/client/js/module/errorHandler/errorManagement';
import EnemyBlockMoveBattingZone from '@/client/js/views/game/indianPocker/fns/common/EnemyBlockMoveBattingZone';
import saveBetCoinSession from '@/client/js/views/game/indianPocker/fns/common/saveBetCoinSession';
import betUserCheck from '@/client/js/views/game/indianPocker/fns/gameState/statePlaying/betUserCheck';

export const GET_BETTING = {
  sessionExtraBet: (_data) => {
    const PROMISE = new Promise(function (resolve, reject) {
      resolve(_data);
    });
    PROMISE
      .then((_data) => {
        // storageMethod('s', 'SET_ITEM', 'betUser', Boolean(_data.bet));
        storageMethod('s', 'SET_ITEM',
          findCharCode([72, 70, 85, 67, 83, 68, 89, 82, 77, 88]), // betUser
          findCharCode([69, 67, 72, 65, 74, 68, 73, 80, 66, 75]) // true
        );
        storageMethod('s', 'SET_ITEM',
          findCharCode([83, 78, 84, 68, 66, 80, 71, 65, 67, 87]), // coinsEnemy
          enc(_data.coinCount)
        );
        storageMethod('s', 'SET_ITEM',
          findCharCode([67, 79, 66, 70, 75, 82, 74, 88, 69, 68]), // coinsEnemyBet
          enc(_data.coinBet)
        );
        storageMethod('s', 'SET_ITEM',
          findCharCode([80, 73, 68, 65, 90, 69, 88, 86, 82, 67]), // coinsEnemyExtBet
          enc(_data.extBet)
        );

        GET_BETTING.drawExtEnemyBet(_data);
      })
      .catch((error) => {
        console.log('error GET_BETTING.sessionExtraBet');
        errorManagement({ errCase: 'errorComn' });
      });
  },
  drawExtEnemyBet: (_data) => {
    console.log('firstExtBet >>>>>>>>>>>>> ', _data);
    EnemyBlockMoveBattingZone().then(() => {
      GET_BETTING.sessionExtBetCoinPos(_data);
    });
  },
  sessionExtBetCoinPos: (_data) => {
    const ENEMY_POS = window.sessionStorage.betCoin;
    if (!ENEMY_POS) return;
    const BET_COIN_LIST = JSON.parse(window.sessionStorage.betCoin);
    if (!BET_COIN_LIST || BET_COIN_LIST.length <= 0) return;

    // const COINS_ENEMY_EXT_BET = window.sessionStorage.coinsEnemyExtBet;
    const encryptKey1 = findCharCode([80, 73, 68, 65, 90, 69, 88, 86, 82, 67]); // coinsEnemyExtBet
    const encryptVal1 = window.sessionStorage.getItem(encryptKey1);
    const decryptVal1 = encryptVal1 !== null && encryptVal1 !== '' ? dec(encryptVal1) : 0; // coinsEnemyExtBet value number

    // const NUMS = Number(COINS_ENEMY_EXT_BET) || 0;
    const NUMS = Number(decryptVal1);

    const COINS_ENEMY = document.querySelector('.coins-enemy');
    if (!COINS_ENEMY) return;
    const COINS = COINS_ENEMY.querySelectorAll('li');
    const COINS_WIDTH = COINS && COINS.length > 0 ? COINS[0].clientWidth : 0;
    const COINS_HEIGHT = COINS && COINS.length > 0 ? COINS[0].clientHeight : 0;
    let x = 0;
    let y = 0;
    let xRes = 0;
    for (let i = BET_COIN_LIST.length - 1; i > BET_COIN_LIST.length - 1 - NUMS; i--) {
      xRes = BET_COIN_LIST[i].translateX < 0 ? BET_COIN_LIST[i].translateX + COINS_WIDTH : BET_COIN_LIST[i].translateX;
      x = BET_COIN_LIST[i].offsetLeft + xRes;
      y = BET_COIN_LIST[i].translateY - COINS_ENEMY.clientHeight + COINS_HEIGHT;
      saveBetCoinSession('enemy', x, y);
    }
    // enemy coins 모두 제거
    setTimeout(GET_BETTING.removeExtEnemyCoins, timeInterval_1, _data);
  },
  removeExtEnemyCoins: (_data) => {
    const COINS_ENEMY = document.querySelector('.coins-enemy');
    if (!COINS_ENEMY) return;
    const ENEMY_COINS = COINS_ENEMY.querySelectorAll('li');
    if (ENEMY_COINS && ENEMY_COINS.length > 0) {
      for (let i = 0; i < ENEMY_COINS.length; i++) {
        ENEMY_COINS[i].remove();
      }
    }
    setTimeout(GET_BETTING.redrawCoinsEnemy, timeInterval_1, _data);
  },
  redrawCoinsEnemy: (_data) => {
    // const COINS_ENEMY = window.sessionStorage.coinsEnemy;
    // const COINS_ENEMY_NUM = Number(COINS_ENEMY) || 0;
    const encryptKey1 = findCharCode([83, 78, 84, 68, 66, 80, 71, 65, 67, 87]); // coinsEnemy
    const encryptVal1 = window.sessionStorage.getItem(encryptKey1);
    const decryptVal1 = encryptVal1 ? dec(encryptVal1) : 0; // coinsEnemy value number

    const COINS_ENEMY_EL = document.querySelector('.coins-enemy');
    if (!COINS_ENEMY_EL) return;
    let liEl = new Object();
    let minuteEl = new Object();
    let hourEl = new Object();
    // for (let i = 0; i < COINS_ENEMY_NUM; i++) {
    for (let i = 0; i < decryptVal1; i++) {
      liEl = document.createElement('li');
      minuteEl = document.createElement('span');
      hourEl = document.createElement('span');
      minuteEl.classList.add('m');
      hourEl.classList.add('h');
      liEl.appendChild(minuteEl);
      liEl.appendChild(hourEl);
      COINS_ENEMY_EL.appendChild(liEl);
    }
    setTimeout(GET_BETTING.removeCoinsEnemyBet, timeInterval_1, _data);
  },
  removeCoinsEnemyBet: (_data) => {
    const BET_COINS = document.querySelector('.bet-coins');
    if (!BET_COINS) return;
    const COINS = BET_COINS.querySelectorAll('li');
    if (COINS && COINS.length > 0) {
      for (let i = 0; i < COINS.length; i++) {
        COINS[i].remove();
      }
    }
    setTimeout(GET_BETTING.redrawCoinsEnemyBet, timeInterval_1, _data);
  },
  redrawCoinsEnemyBet: (_data) => {
    const BET_COINS = document.querySelector('.bet-coins');
    if (!BET_COINS) return;
    const BET_COIN_POS = window.sessionStorage.betCoinPos;
    if (!BET_COIN_POS) return;
    const POS_ARR = JSON.parse(BET_COIN_POS);
    if (!POS_ARR || POS_ARR.length <= 0) return;
    let liEl = new Object();
    let minuteEl = new Object();
    let hourEl = new Object();
    for (let i = 0; i < POS_ARR.length; i++) {
      liEl = document.createElement('li');
      minuteEl = document.createElement('span');
      hourEl = document.createElement('span');
      minuteEl.classList.add('m');
      hourEl.classList.add('h');
      liEl.appendChild(minuteEl);
      liEl.appendChild(hourEl);
      if (POS_ARR[i].host === 'enemy') liEl.classList.add('e');
      liEl.style.transform = 'translate(' + POS_ARR[i].translateX + 'px, ' + POS_ARR[i].translateY + 'px)';
      BET_COINS.appendChild(liEl);
    }

    if (_data.state === comnText.call) {
    } else {
      setTimeout(betUserCheck, timeInterval_1);
    }
  },
};
