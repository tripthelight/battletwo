import booleanReturn from '@/client/js/functions/validation/booleanReturn';
import findCharCode from '@/client/js/functions/findCharCode';
import { timeInterval_1, timeInterval_2 } from '@/client/js/functions/variable';
import { errorManagement } from '@/client/js/module/errorHandler/errorManagement';
import moveCoins from '@/client/js/views/game/indianPocker/fns/common/moveCoins';
import subtractMoveCoin from '@/client/js/views/game/indianPocker/fns/common/subtractMoveCoin';
import { BTN_STATE } from '@/client/js/views/game/indianPocker/fns/rule/btnState';
import { LOADING_EVENT } from '@/client/components/popup/full/loading';
import disabledMoveCoins from '@/client/js/views/game/indianPocker/fns/common/disabledMoveCoins';

export default () => {
  // element | seeeion 체크
  const ENEMY_CARD = document.querySelector('.enemy-card');
  if (!ENEMY_CARD) return;
  const PLAYER_BLOCK = document.querySelector('.player-block');
  if (!PLAYER_BLOCK) return;
  const COINS_PLAYER = document.querySelector('.coins-player');
  if (!COINS_PLAYER) return;
  // const BET_USER = window.sessionStorage.betUser;
  // if (!BET_USER) return errorManagement({ errCase: 'sessionStorageLoss', message: 'betUser 세션이 없습니다.' });
  const decryptVal1 = booleanReturn([72, 70, 85, 67, 83, 68, 89, 82, 77, 88]); // betUser - true or false or error
  if (decryptVal1 === '')  return errorManagement({ errCase: 'sessionStorageLoss', message: '코인 1 체크 중 betUser 세션이 없습니다.' });
  // const BAT_STATE = window.sessionStorage.betState;
  // if (!BAT_STATE) return errorManagement({ errCase: 'sessionStorageLoss', message: 'betState 세션이 없습니다.' });
  const encryptKey1 = findCharCode([70, 77, 80, 88, 87, 86, 83, 89, 75, 65]); // betState
  const encryptVal1 = window.sessionStorage.getItem(encryptKey1);
  if (encryptVal1 === null) return errorManagement({ errCase: 'sessionStorageLoss', message: 'betState 세션이 없습니다.' });


  // 명령
  setTimeout(() => {
    // if (BET_USER === 'true') {
    // betUser === true
    if (decryptVal1) {
      ENEMY_CARD.classList.add('disabled');
      PLAYER_BLOCK.classList.remove('disabled');
      COINS_PLAYER.classList.remove('disabled');

      // 다음 함수 실행
      // if (BAT_STATE === 'basicBetting') {
      // betState === basicBetting
      if (encryptVal1 === findCharCode([70, 84, 75, 87, 74, 67, 73, 77, 80, 65])) {
        setTimeout(moveCoins, timeInterval_1);
      }
      // if (encryptVal1 === 'extraBetting') {
      // betState === extraBetting
      if (encryptVal1 === findCharCode([77, 86, 83, 87, 69, 73, 72, 88, 80, 89])) {
        setTimeout(moveCoins, timeInterval_1);
        setTimeout(subtractMoveCoin, timeInterval_1);
        setTimeout(BTN_STATE.SHOW, timeInterval_2);
      }
    // } else if (BET_USER === 'false') {
    // betUser === false
    } else if (!decryptVal1) {
      ENEMY_CARD.classList.remove('disabled');
      PLAYER_BLOCK.classList.add('disabled');
      COINS_PLAYER.classList.add('disabled');

      // 다음 함수 실행
      setTimeout(disabledMoveCoins, timeInterval_1);
    } else {
      return errorManagement({ errCase: 'sessionStorageLoss', message: 'betUser 세션이 true나 false가 아닙니다.' });
    }
    setTimeout(() => {
      LOADING_EVENT.hide();
    }, timeInterval_1);
  }, timeInterval_1);
};
