import findCharCode from '@/client/js/functions/findCharCode';
import { dec } from '@/client/js/module/crypts/obf8lower';
import booleanReturn from '@/client/js/functions/validation/booleanReturn';
import deviceStateStore from '@/client/store/deviceStateStore';
import { errorManagement } from '@/client/js/module/errorHandler/errorManagement';
import { timeInterval_1 } from '@/client/js/functions/variable';
import animateClock from '@/client/js/views/game/indianPocker/fns/common/animateClock';
import posClock from '@/client/js/views/game/indianPocker/fns/common/posClock';
import refreshFindEnemyCardNumber from '@/client/js/views/game/indianPocker/fns/gameState/statePlaying/refreshFindEnemyCardNumber';

export default () => {
  // element | seeeion 체크
  const COINS_PLAYER = document.querySelector('.coins-player');
  if (COINS_PLAYER) return;
  const PLAYER_BLOCK = document.querySelector('.player-block');
  if (!PLAYER_BLOCK) return;

  // const BET_USER = window.sessionStorage.betUser;
  // if (!BET_USER) return errorManagement({ errCase: 'sessionStorageLoss', message: 'betUser not found' });
  // const BET_STATE = BET_USER === 'true' ? true : false;
  const decryptVal1 = booleanReturn([72, 70, 85, 67, 83, 68, 89, 82, 77, 88]); // betUser - true or false or error
  if (decryptVal1 === '')  return errorManagement({ errCase: 'sessionStorageLoss', message: '코인 1 체크 중 betUser 세션이 없습니다.' });

  console.log("decryptVal1 ------------- 3 : ", decryptVal1);

  // 명령
  // 새로 고침 시 여기를 탐
  const elem = document.createElement('ul');
  let liEl = new Object();
  let minuteEl = new Object();
  let hourEl = new Object();
  elem.classList.add('coins');
  elem.classList.add('coins-player');
  // let coinCount = Number(window.sessionStorage.coinsPlayer);
  const encryptKey2 = findCharCode([81, 67, 69, 68, 71, 77, 83, 90, 65, 74]);  // coinsPlayer
  const encryptVal2 = window.sessionStorage.getItem(encryptKey2);
  const decryptVal2 = dec(encryptVal2); // coinsPlayer value number
  // coinCount가 0일 수 있음
  // for (let i = 0; i < coinCount; i++) {
  // decryptVal2가 0일 수 있음
  for (let i = 0; i < Number(decryptVal2); i++) {
    liEl = document.createElement('li');
    minuteEl = document.createElement('span');
    hourEl = document.createElement('span');
    minuteEl.classList.add('m');
    hourEl.classList.add('h');
    liEl.appendChild(minuteEl);
    liEl.appendChild(hourEl);
    const deviceState = deviceStateStore.getState().deviceStateState.deviceState;
    if (deviceState === 'pc') liEl.setAttribute('draggable', true);
    elem.appendChild(liEl);
    // 내 차례면 player coin은 시간이 가고고, 내 차례가 아니면 player coin은 시간이 멈춤
    decryptVal1 ? animateClock(hourEl, minuteEl, false) : posClock(hourEl, minuteEl);
  }
  PLAYER_BLOCK.appendChild(elem);

  // 다음 함수 실행
  refreshFindEnemyCardNumber();
};
